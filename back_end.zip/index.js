const express = require("express");
const app = express();
const mysql = require("mysql");
const cors = require("cors");

app.use(cors());
app.use(express.json());
const db = mysql.createConnection({
    user: "root",
    host : "localhost",
    password : "",
    database : "blms",
});

app.post("/create", (req, res) => {
    console.log(req.body);
    const cust_name = req.body.cust_name;
    const cust_id = req.body.cust_id;
    const bank_cust_id = req.body.cust_id;
    const gender = req.body.gender;
    const age = req.body.age;
    const mobile = req.body.mobile;
    const income = req.body.income;
    const acc_no = req.body.acc_no;
    const acc_bal = req.body.acc_bal;
    const branch = req.body.branch;

  
    db.query(
        "INSERT INTO customer (cust_id ,cust_name, gender, age, mobile, income) values (?,?,?,?,?,?)",
        [cust_id, cust_name,gender,age,mobile,income]
        );

    db.query(
        "INSERT INTO bank (bank_cust_id ,acc_no, acc_bal, branch) values (?,?,?,?)",
        [bank_cust_id , acc_no, acc_bal, branch],
    );
  });

app.post("/addloan", (req, res) => {
    console.log(req.body);
    const loan_cust_id = req.body.cust_id;
    const loan_id = req.body.loan_id;
    const loan_amt = req.body.loan_amt;
    const int_rate = req.body.int_rate;
    const duration = req.body.duration;
    const loan_type = req.body.loan_type;
    const emi_loan_id = req.body.loan_id;
    const emi_loan_amt = req.body.loan_amt;

    global.a = emi_loan_id;

  
    db.query(
        "INSERT INTO loan (loan_cust_id ,loan_id, loan_amt, intr_rate, duration, loan_type) values (?,?,?,?,?,?)",
        [loan_cust_id, loan_id,loan_amt,int_rate,duration,loan_type],
        );

    db.query(
        "INSERT INTO emi (emi_loan_id,emi_loan_amt) values (?,?)",
        [emi_loan_id,emi_loan_amt],
    );

    db.query(
        "update emi e set e.emi_amt = (select (loan_amt* duration* intr_rate)/100 from loan l where e.emi_loan_id=l.loan_id) where e.emi_loan_id = (?);",
        [emi_loan_id],
    );
    
    db.query(
        "update emi e set e.emi_pm = e.emi_amt/(select duration from loan l where e.emi_loan_id=l.loan_id) where e.emi_loan_id = (?);",
        [emi_loan_id],
    );

    db.query(
        "update emi e set e.no_of_emi = (select duration from loan l where e.emi_loan_id = l.loan_id) where e.emi_loan_id = (?);",
        [emi_loan_id],
    )

    db.query(
        "update emi e set e.pending_emi = e.no_of_emi where e.emi_loan_id = (?);",
        [emi_loan_id],
    )

  });

app.get('/getCust', (req, res) => {
    db.query("SELECT * from bank b,customer c where b.bank_cust_id=c.cust_id", (err, result) => {
        if(err){
            console.log(err)
        } else{
             res.send(result)
        }
    });
    
});

app.get('/getLoan', (req,res) => {
    db.query("SELECT * FROM emi e, loan l where l.loan_id = e.emi_loan_id;" , (err, result) => {
        if(err){
            console.log(err)
        }else{
            res.send(result)
        }
    });
})

app.post("/amort", (req, res) => {
    console.log(req.body);
    const amort_id = req.body.amort_id;
    const amort_loan_id = req.body.amort_loan_id;
    const no_of_emi_paid = req.body.no_of_emi_paid;

  
    db.query(
        "INSERT INTO amortisation(amort_id ,amort_loan_id, no_of_emi_paid) values (?,?,?)",
        [amort_id, amort_loan_id,no_of_emi_paid]
    )

    db.query(
        "update blms.emi e set e.pending_emi = e.pending_emi - (?) where e.emi_loan_id=(?);",
        [no_of_emi_paid,amort_loan_id]
    )

  });





app.listen(3002, () => {
    console.log("Arutperunjothi");
})